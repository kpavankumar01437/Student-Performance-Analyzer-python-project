import operator

# --- Constants ---
PASS_MARK = 40
DISTINCTION_MARK = 75
REQUIRED_SUBJECTS = 3

def analyze_student_performance(student_data):
    """
    Calculates average, pass/fail status, and distinction status for each student.
    """
    if not student_data:
        return []

    for student in student_data:
        total_marks = sum(student['marks'])
        average = total_marks / len(student['marks'])
        student['average'] = round(average, 2)

        # Pass/Fail Check: Must pass all subjects (mark >= 40)
        student['pass_fail'] = "PASS" if all(m >= PASS_MARK for m in student['marks']) else "FAIL"

        # Distinction Check: Average must meet the distinction mark (75) AND the student must have passed.
        student['distinction'] = "YES" if student['average'] >= DISTINCTION_MARK and student['pass_fail'] == "PASS" else "NO"

    return student_data

def rank_students(student_data):
    """
    Ranks students based on their average marks (highest to lowest).
    """
    # Sort the list of dictionaries by 'average' in descending order
    ranked_students = sorted(student_data, key=operator.itemgetter('average'), reverse=True)

    # Assign rank
    rank = 0
    previous_average = -1
    for i, student in enumerate(ranked_students):
        if student['average'] < previous_average or previous_average == -1:
            rank = i + 1
            previous_average = student['average']
        student['rank'] = rank

    return ranked_students

def generate_report(ranked_students):
    """
    Generates and prints the final report, including individual results and class summary.
    """
    if not ranked_students:
        print("\n--- Final Report ---")
        print("No student data available to generate a report.")
        return

    # --- Individual Results Table ---
    print("\nClass Student Performance Report")
    print("-" * 80)

    # Table Header
    header = f"{'Rank':<5}{'Name':<20}{'Marks':<15}{'Average':<10}{'Pass/Fail':<12}{'Distinction':<15}"
    print(header)
    print("-" * 80)

    # Table Rows
    for student in ranked_students:
        marks_str = "/".join(map(str, student['marks']))
        row = (
            f"{student['rank']:<5}"
            f"{student['name']:<20}"
            f"{marks_str:<15}"
            f"{student['average']:<10.2f}"
            f"{student['pass_fail']:<12}"
            f"{student['distinction']:<15}"
        )
        print(row)

    # --- Class Summary ---
    print("\nClass Summary Statistics")
    print("-" * 30)
    
    # Calculate summary metrics
    averages = [s['average'] for s in ranked_students]
    
    # Highest and Lowest Average
    class_highest_avg = max(averages)
    class_lowest_avg = min(averages)
    
    # Pass/Fail Count
    num_passed = sum(1 for s in ranked_students if s['pass_fail'] == "PASS")
    num_failed = len(ranked_students) - num_passed
    
    # Distinction Holders
    distinction_holders = [s['name'] for s in ranked_students if s['distinction'] == "YES"]
    
    # Display Summary
    print(f"* Class Size: {len(ranked_students)} students")
    print(f"* Class Highest Average: {class_highest_avg:.2f}")
    print(f"* Class Lowest Average: {class_lowest_avg:.2f}")
    print(f"* Students Passed: {num_passed}")
    print(f"* Students Failed: {num_failed}")
    
    print("\n### List of Distinction Holders")
    if distinction_holders:
        print(", ".join(distinction_holders))
    else:
        print("No students achieved distinction.")

def main():
    """
    Main function using the user-provided, direct input data.
    """
    print("Welcome to the Student Performance Analyzer (Pre-loaded Data)")
    
    # 1. Direct Input Data
    student_data = [
        {'name': 'spandhana', 'marks': [100, 99, 98]},
        {'name': 'sahithya', 'marks': [35, 56, 75]}, 
        {'name': 'vyshnavi', 'marks': [78, 86, 93]},
    ]
    
    # 2. Analyze Data
    analyzed_data = analyze_student_performance(student_data)
    
    # 3. Rank Data
    ranked_data = rank_students(analyzed_data)
    
    # 4. Generate Report
    generate_report(ranked_data)

# --- THE FIX IS HERE ---
if __name__ == "__main__":
    main()